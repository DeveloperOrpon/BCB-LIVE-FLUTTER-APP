import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class Globals {
  Globals._();

  static const Color colorGreen = Color.fromRGBO(38, 58, 41, 1);
  static const Color colorRed = Color.fromRGBO(223, 46, 56, 1);
}

List<String> imageListOfBanner = [
  'assets/images/pic-3.jpg',
  'assets/images/pic-2.jpg',
  'assets/images/pic-1.jpg',
];
startLoading(String text) async {
  await EasyLoading.show(
    dismissOnTap: false,
    status: text,
    indicator: Image.asset(
      'assets/images/loading.gif',
      color: Colors.blue,
      width: 120,
      height: 80,
      fit: BoxFit.fitWidth,
    ),
  );
}
