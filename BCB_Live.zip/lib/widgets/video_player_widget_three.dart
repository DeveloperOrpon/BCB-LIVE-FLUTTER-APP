import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../providers/highlights_provider.dart';

class VideoPlayerScreen extends StatefulWidget {
  final Highlight highlight;

  const VideoPlayerScreen(this.highlight, {super.key});

  @override
  _VideoPlayerScreenState createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late String videoTitle;
  // Url List
  final List<String> _videoUrlList = [
    'https://youtu.be/8wb3hiF20bQ',
    'https://www.youtube.com/watch?v=668nUCeBHyY',
    'https://youtu.be/S3npWREXr8s',
  ];

  List<YoutubePlayerController> lYTC = [];
  late YoutubePlayerController _ytController;
  Map<String, dynamic> cStates = {};

  @override
  void initState() {
    super.initState();
    fillYTlists();
  }

  fillYTlists() {
    String _id = YoutubePlayer.convertUrlToId(widget.highlight.videoUrl)!;
    _ytController = YoutubePlayerController(
      initialVideoId: _id,
      flags: const YoutubePlayerFlags(
        autoPlay: false,
        enableCaption: true,
        captionLanguage: 'en',
      ),
    );

    _ytController.addListener(() {
      print('for $_id got isPlaying state ${_ytController.value.isPlaying}');
      if (cStates[_id] != _ytController.value.isPlaying) {
        if (mounted) {
          setState(() {
            cStates[_id] = _ytController.value.isPlaying;
          });
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220.0,
      decoration: const BoxDecoration(
        color: Color(0xfff5f5f5),
        borderRadius: BorderRadius.all(Radius.circular(12)),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        child: YoutubePlayer(
          controller: _ytController,
          showVideoProgressIndicator: true,
          progressIndicatorColor: Colors.lightBlueAccent,
          bottomActions: [
            CurrentPosition(),
            ProgressBar(isExpanded: true),
            FullScreenButton(),
          ],
          onReady: () {
            print('onReady for');
          },
          onEnded: (YoutubeMetaData _md) {
            _ytController.seekTo(const Duration(seconds: 0));
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
